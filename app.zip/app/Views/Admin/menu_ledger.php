
<a href="#" onclick="showData('<?php echo site_url('/Admin/Ledger_nagodan_ajax'); ?>','<?php echo '/Admin/Ledger_nagodan';?>')"  class="btn btn-default" style="margin-bottom: 5px;">Ledger Cash</a>

<a href="#" onclick="showData('<?php echo site_url('/Admin/Ledger_bank_ajax'); ?>','<?php echo '/Admin/Ledger_bank';?>')"  class="btn btn-default" style="margin-bottom: 5px;">Ledger Bank</a>

<a href="#" onclick="showData('<?php echo site_url('/Admin/Ledger_loan_ajax'); ?>','<?php echo '/Admin/Ledger_loan';?>')"  class="btn btn-default" style="margin-bottom: 5px;">Account Head</a>

<a href="#" onclick="showData('<?php echo site_url('/Admin/Ledger_ajax'); ?>','<?php echo '/Admin/Ledger';?>')"  class="btn btn-default" style="margin-bottom: 5px;">Ledger Customer</a>

<a href="#" onclick="showData('<?php echo site_url('/Admin/Ledger_suppliers_ajax'); ?>','<?php echo '/Admin/Ledger_suppliers';?>')"  class="btn btn-default" style="margin-bottom: 5px;">Ledger Suppliers</a>
<a href="#" onclick="showData('<?php echo site_url('/Admin/Ledger_purchase_ajax'); ?>','<?php echo '/Admin/Ledger_purchase';?>')"  class="btn btn-default" style="margin-bottom: 5px;">Ledger Purchase</a>

<a href="#" onclick="showData('<?php echo site_url('/Admin/Ledger_sales_ajax'); ?>','<?php echo '/Admin/Ledger_sales';?>')"  class="btn btn-default" style="margin-bottom: 5px;">Ledger Sales</a>


<a href="#" onclick="showData('<?php echo site_url('/Admin/Ledger_stock_ajax'); ?>','<?php echo '/Admin/Ledger_stock';?>')"  class="btn btn-default" style="margin-bottom: 5px;">Ledger Stock</a>
<a href="#" onclick="showData('<?php echo site_url('/Admin/Ledger_expense_ajax'); ?>','<?php echo '/Admin/Ledger_expense';?>')"  class="btn btn-default" style="margin-bottom: 5px;">Ledger Expense</a>
<a href="#" onclick="showData('<?php echo site_url('/Admin/Ledger_profit_ajax'); ?>','<?php echo '/Admin/Ledger_profit';?>')"  class="btn btn-default" style="margin-bottom: 5px;">Ledger Profit</a>
<a href="#" onclick="showData('<?php echo site_url('/Admin/Ledger_capital_ajax'); ?>','<?php echo '/Admin/Ledger_capital';?>')"  class="btn btn-default" style="margin-bottom: 5px;">Ledger Capital</a>

<a href="#" onclick="showData('<?php echo site_url('/Admin/Ledger_vat_ajax'); ?>','<?php echo '/Admin/Ledger_vat';?>')"  class="btn btn-default" style="margin-bottom: 5px;">Ledger Vat</a>

<a href="#" onclick="showData('<?php echo site_url('/Admin/Ledger_other_sales_ajax'); ?>','<?php echo '/Admin/Ledger_other_sales';?>')"  class="btn btn-default" style="margin-bottom: 5px;">Ledger other sales</a>

<a href="#" onclick="showData('<?php echo site_url('/Admin/Ledger_discount_ajax'); ?>','<?php echo '/Admin/Ledger_discount';?>')"  class="btn btn-default" style="margin-bottom: 5px;">Ledger discount</a>


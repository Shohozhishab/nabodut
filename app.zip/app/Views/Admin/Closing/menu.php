
<a href="#" onclick="showData('<?php echo site_url('/Admin/Closing_ajax/cash') ?>','/Admin/Closing/cash')" class="btn btn-default">Cash</a>
<a href="#" onclick="showData('<?php echo site_url('/Admin/Closing_ajax/bank') ?>','/Admin/Closing/bank')" class="btn btn-default">Bank</a>
<a href="#" onclick="showData('<?php echo site_url('/Admin/Closing_ajax/capital') ?>','/Admin/Closing/capital')" class="btn btn-default">Capital</a>
<a href="#" onclick="showData('<?php echo site_url('/Admin/Closing_ajax/stock') ?>','/Admin/Closing/stock')" class="btn btn-default">Stock Amount </a>

<a href="#" onclick="showData('<?php echo site_url('/Admin/Closing_ajax/customers/'); ?>','<?php echo '/Admin/Closing/customers/';?>')"  class="btn btn-default">Customer</a>
<a href="#" onclick="showData('<?php echo site_url('/Admin/Closing_ajax/accountHolder') ?>','/Admin/Closing/accountHolder')" class="btn btn-default">Account Head</a>
<a href="#" onclick="showData('<?php echo site_url('/Admin/Closing_ajax/suppliers') ?>','/Admin/Closing/suppliers')" class="btn btn-default">Suppliers</a>
<a href="#" onclick="showData('<?php echo site_url('/Admin/Closing_ajax/employe') ?>','/Admin/Closing/employe')" class="btn btn-default">Employe</a>
<a href="#" onclick="showData('<?php echo site_url('/Admin/Closing_ajax/expense') ?>','/Admin/Closing/expense')" class="btn btn-default">Expense</a>
<a href="#" onclick="showData('<?php echo site_url('/Admin/Closing_ajax/profit') ?>','/Admin/Closing/profit')" class="btn btn-default">Profit</a>
<a href="#" onclick="showData('<?php echo site_url('/Admin/Closing_ajax/ledger_vat') ?>','/Admin/Closing/ledger_vat')" class="btn btn-default">Ledger Vat</a>
<a href="#" onclick="showData('<?php echo site_url('/Admin/Closing_ajax/products') ?>','/Admin/Closing/products')" class="btn btn-default">Products</a>

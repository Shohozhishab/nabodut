<div class="content-wrapper" id="viewpage">
    <section class="content-header">
      <h1>No Permission!</h1>
    </section>

    
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
        
    
<div class="box">
        
        <div class="box-body">
            
            
        <div class="row"/>
        <div class="col-md-12">
        Sorry! You don't have permission on this page.
        </div>
        </div>
        
</div>
</div>
</div>
</section>
</div>